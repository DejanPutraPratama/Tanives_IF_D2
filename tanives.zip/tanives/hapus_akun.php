<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$username = $_POST['username'];

// Menyiapkan query untuk menghapus data dari tabel akun
$query = "DELETE FROM akun WHERE username = '$username'";

// mengeksekusi query
if(mysqli_query($conn, $query)) {
    // jika berhasil, kembalikan echo 200
    echo "200";
} else {
    // jika username tidak ditemukan, kembalikan echo 101
    echo "101";
}

mysqli_close($conn);
?>
