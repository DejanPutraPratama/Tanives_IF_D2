<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$username = $_POST['username'];

// Menyiapkan query untuk mengambil data dari tabel aset
$query = "SELECT a.id, a.tanggal_pembelian, a.nilai, a.keterangan, a.latitude, a.longitude, a.lokasi, j.jenis AS jenis, s.status FROM aset a LEFT JOIN jenis_aset j ON a.id_jenis = j.id LEFT JOIN status s ON a.id_status = s.id WHERE a.id_profile = '$username'";

// mengeksekusi query dan mendapatkan hasilnya
$result = mysqli_query($conn, $query);

// memproses hasil query menjadi string dengan format yang diinginkan
$data = "";
while ($row = mysqli_fetch_assoc($result)) {
    $data .= $row['id'] . "||" . $row['tanggal_pembelian'] . "||" . $row['nilai'] . "||" . $row['keterangan'] . "||" . $row['latitude'] ."||" . $row['longitude'] . "||" . $row['lokasi'] . "||" . $row['jenis'] . "||" . $row['status'] . ";";
}

// mengembalikan data sebagai hasil
echo $data;

mysqli_close($conn);
?>