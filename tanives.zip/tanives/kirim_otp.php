<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$id_akun = $_POST['id_akun'];
$email = $_POST['email'];

// Menyiapkan query untuk mengambil data dari tabel profile
$query = "SELECT * FROM profile WHERE id_akun = '$id_akun' AND email = '$email'";

// mengeksekusi query dan mendapatkan hasilnya
$result = mysqli_query($conn, $query);

// jika data tidak ditemukan
if (mysqli_num_rows($result) == 0) {
  echo 102;
  exit;
}

// generate OTP
$otp = mt_rand(10000, 99999);

$url = "https://script.google.com/macros/s/AKfycbw12zxIEESqm85dp_BEflH_WIvR19o69JpVO6VnsAp31mF2-eYYUJkQjpSNXJGKuwAczQ/exec";
$data = array(
  "email" => "$email",
  "message" => "Kode otp reset password anda adalah $otp"
);

$options = array(
  'http' => array(
    'method' => 'POST',
    'content' => http_build_query($data),
  ),
);
$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);

if ($response == 400) {
  echo $otp;
} else {
  echo 101;
}
?>

