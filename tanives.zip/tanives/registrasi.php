<?php
//koneksi ke database
include "koneksi.php";

//menerima input data dari form
$email = $_POST["email"];
$nama = $_POST["nama"];
$tanggal_lahir = $_POST["tanggal_lahir"];
$nomor_hp = $_POST["nomor_hp"];
$alamat = $_POST["alamat"];
$tipe = $_POST["tipe"];
$username = $_POST["username"];
$password = mysqli_real_escape_string($conn, $_POST["password"]);

//enkrpsi password dengan BCrypt
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

//mengecek apakah email atau username sudah terdaftar sebelumnya
$sql_check = "SELECT * FROM akun WHERE username='$username'";
$result_check = mysqli_query($conn, $sql_check);

//jika username sudah ada, tampilkan pesan error "101"
if (mysqli_num_rows($result_check) > 0) {
    echo "101";
} else {
    //jika username belum ada, simpan data akun ke dalam database
    $sql_akun = "INSERT INTO akun (username, password) VALUES ('$username', '$hashed_password')";
    mysqli_query($conn, $sql_akun);

    //ambil id_akun terakhir yang di-generate oleh database
    $id_akun = mysqli_insert_id($conn);

    //simpan data profil ke dalam database
    $sql_profil = "INSERT INTO profile (email, nama, tanggal_lahir, nomor_hp, alamat, tipe, id_akun) 
                   VALUES ('$email', '$nama', '$tanggal_lahir', '$nomor_hp', '$alamat', '$tipe', '$username')";
    mysqli_query($conn, $sql_profil);

    //tampilkan pesan sukses "200"
    echo "200";
}

//tutup koneksi
mysqli_close($conn);
?>