<?php
include "koneksi.php";

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$type = $_POST['type'];

// Mencari data password berdasarkan username
$sql = "SELECT password FROM akun WHERE username = '$username'";
$result = mysqli_query($conn, $sql);

// Memeriksa apakah username ditemukan dalam database
if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);

  // Memeriksa apakah password yang dimasukkan cocok dengan password di database
  if (password_verify($password, $row['password'])) {

    // Memeriksa tipe akun pada tabel profile
    $sql_profile = "SELECT tipe FROM profile WHERE id_akun = '$username'";
    $result_profile = mysqli_query($conn, $sql_profile);

    if (mysqli_num_rows($result_profile) == 1) {
      $row_profile = mysqli_fetch_assoc($result_profile);

      // Memeriksa apakah tipe akun sesuai
      if ($type == $row_profile['tipe']) {
        echo "200";
      } else {
        echo "102"; // Tipe akun tidak sesuai
      }
    } else {
      echo "103"; // Tidak ditemukan data profile yang sesuai
    }

  } else {
    echo "101"; // Password tidak cocok
  }
} else {
  echo "100"; // Username tidak ditemukan
}
?>

