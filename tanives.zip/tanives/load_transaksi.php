<?php
include "koneksi.php";

$id_profile = $_POST['id_profile'];
$tanggal_awal = $_POST['tanggal_awal'];
$tanggal_akhir = $_POST['tanggal_akhir'];

$query = "SELECT * FROM laporan_keuangan WHERE id_profile = '$id_profile' AND tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
  $output = "";
  while ($row = mysqli_fetch_assoc($result)) {
    $output .= $row['id'] . "||" . $row['transaksi_keluar'] . "||" . $row['transaksi_masuk'] . "||" . $row['tanggal'] . "||" . $row['waktu'] . "||" . $row['keterangan'] . ";";
  }
  echo $output;
} else {
  echo 101;
}

mysqli_close($conn);
?>
