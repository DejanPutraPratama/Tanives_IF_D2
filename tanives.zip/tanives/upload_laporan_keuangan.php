<?php
// mengambil data inputan dari request
$transaksi_keluar = $_POST['transaksi_keluar'];
$transaksi_masuk = $_POST['transaksi_masuk'];
$tanggal = $_POST['tanggal'];
$waktu = $_POST['waktu'];
$keterangan = $_POST['keterangan'];
$id_profile = $_POST['id_profile'];
$id_pesanan = $_POST['id_pesanan'];
$id_konsultasi = $_POST['id_konsultasi'];

// melakukan koneksi ke database
include "koneksi.php";

// menyiapkan query untuk memasukkan data ke dalam tabel laporan_keuangan
$query = "INSERT INTO laporan_keuangan (transaksi_keluar, transaksi_masuk, tanggal, waktu, keterangan, id_profile, id_pesanan, id_konsultasi) VALUES ('$transaksi_keluar', '$transaksi_masuk', '$tanggal', '$waktu', '$keterangan', '$id_profile', '$id_pesanan', '$id_konsultasi')";

// mengeksekusi query dan mengecek apakah query berhasil dijalankan
if(mysqli_query($koneksi, $query)) {
    http_response_code(200);
    echo "Data berhasil disimpan";
} else {
    http_response_code(101);
    echo "Data gagal disimpan";
}
?>
