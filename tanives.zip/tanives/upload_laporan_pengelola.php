<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$keuangan = $_POST['keuangan'];
$gambar = $_POST['gambar'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$deskripsi = $_POST['deskripsi'];
$id_aset = $_POST['id_aset'];
$id_pelapor = $_POST['id_pelapor'];

if($keuangan == 1) {
    // mengambil data inputan dari request
    $transaksi_keluar = $_POST['transaksi_keluar'];
    $transaksi_masuk = $_POST['transaksi_masuk'];
    $tanggal_keuangan = date('Y-m-d');
    $waktu_keuangan = date('H:i:s');
    $keterangan = $_POST['keterangan'];
    $id_profile = $_POST['id_profile'];

    // menyiapkan query untuk memasukkan data ke dalam tabel laporan_keuangan
    $query_keuangan = "INSERT INTO laporan_keuangan (transaksi_keluar, transaksi_masuk, tanggal, waktu, keterangan, id_profile) VALUES ('$transaksi_keluar', '$transaksi_masuk', '$tanggal_keuangan', '$waktu_keuangan', '$keterangan', '$id_profile')";

    // mengeksekusi query laporan keuangan dan mengecek apakah query berhasil dijalankan
    $result_keuangan = mysqli_query($conn, $query_keuangan);

    // mendapatkan id dari transaksi yang baru saja ditambahkan
    $id_transaksi = mysqli_insert_id($conn);
}

// menyiapkan query untuk memasukkan data gambar ke dalam tabel laporan_pengelola
if ($keuangan == 1) {
    $query_pengelola = "INSERT INTO laporan_pengelola (tanggal, waktu, gambar, latitude, longitude, deskripsi, id_aset, id_pelapor, id_transaksi) 
        VALUES (CURDATE(), CURTIME(), '$gambar', '$latitude', '$longitude', '$deskripsi', '$id_aset', '$id_pelapor', '$id_transaksi')";
} else {
    $query_pengelola = "INSERT INTO laporan_pengelola (tanggal, waktu, gambar, latitude, longitude, deskripsi, id_aset, id_pelapor) 
        VALUES (CURDATE(), CURTIME(), '$gambar', '$latitude', '$longitude', '$deskripsi', '$id_aset', '$id_pelapor')";
}

// mengeksekusi query laporan pengelola dan mengecek apakah query berhasil dijalankan
$result_pengelola = mysqli_query($conn, $query_pengelola);

// mengecek apakah kedua query berhasil dijalankan
if ($result_pengelola && (!$keuangan || $result_keuangan)) {
    echo "200";
} else {
    echo "101";
}

mysqli_close($conn);
?>