<?php
include "koneksi.php";

$id_akun = $_POST['username'];
$email = $_POST['email'];
$nama = $_POST['nama'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$nomor_hp = $_POST['nomor_hp'];
$alamat = $_POST['alamat'];
$id_bank = $_POST['id_bank'];
$nomor_rekening = $_POST['nomor_rekening'];
$nama_pemilik = $_POST['nama_pemilik'];
$password = mysqli_real_escape_string($conn, $_POST["password"]);

// Enkripsi password menggunakan BCrypt jika variabel password diisi
if (!empty($password)) {
  $password_hash = password_hash($password, PASSWORD_BCRYPT);
  $query_akun = "UPDATE akun SET password='$password_hash' WHERE id_akun='$id_akun'";
  $result_akun = mysqli_query($conn, $query_akun);
}

$query_profile = "UPDATE profile SET email='$email', nama='$nama', tanggal_lahir='$tanggal_lahir', nomor_hp='$nomor_hp', alamat='$alamat', id_bank='$id_bank', nomor_rekening='$nomor_rekening', nama_pemilik='$nama_pemilik' WHERE id_akun='$id_akun'";
$result_profile = mysqli_query($conn, $query_profile);

if ($result_profile) {
  echo 200;
} else {
  echo 101;
}

mysqli_close($conn);
?>
