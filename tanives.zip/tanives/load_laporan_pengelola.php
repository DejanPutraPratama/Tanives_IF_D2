<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$id_aset = $_POST['id_aset'];
$tanggal_awal = $_POST['tanggal_awal'];
$tanggal_akhir = $_POST['tanggal_akhir'];

// menyiapkan query untuk mengambil data dari tabel laporan_pengelola dan laporan_keuangan
$query = "SELECT lp.id, lp.tanggal, lp.waktu, lp.gambar, lp.latitude, lp.longitude, lp.deskripsi, lp.id_aset, lp.id_pelapor, lp.id_transaksi, lk.transaksi_keluar, lk.transaksi_masuk, lk.keterangan, lk.id_profile 
          FROM laporan_pengelola lp 
          LEFT JOIN laporan_keuangan lk ON lp.id_transaksi = lk.id 
          WHERE lp.id_aset = '$id_aset'";

// menambahkan filter tanggal jika tanggal_awal dan tanggal_akhir diisi
if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
    $query .= " AND lp.tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";
}

// mengeksekusi query dan mendapatkan hasilnya
$result = mysqli_query($conn, $query);

// memproses hasil query menjadi string dengan format yang diinginkan
$data = "";
while ($row = mysqli_fetch_assoc($result)) {
    if (!empty($row['id_transaksi'])) {
        // jika id_transaksi tidak null, susun data dari laporan_pengelola dan laporan_keuangan dalam 1 baris
        $data .= $row['id'] . "||" . $row['tanggal'] . "||" . $row['waktu'] . "||" . $row['gambar'] . "||" . $row['latitude'] . "||" . $row['longitude'] . "||" . $row['deskripsi'] . "||" . $row['id_aset'] . "||" . $row['id_pelapor'] . "||" . $row['id_transaksi'] . "||" . $row['transaksi_keluar'] . "||" . $row['transaksi_masuk'] . "||" . $row['keterangan'] . "||" . $row['id_profile'] . ";";
    } else {
        // jika id_transaksi null, susun data dari laporan_pengelola saja
        $data .= $row['id'] . "||" . $row['tanggal'] . "||" . $row['waktu'] . "||" . $row['gambar'] . "||" . $row['latitude'] . "||" . $row['longitude'] . "||" . $row['deskripsi'] . "||" . $row['id_aset'] . "||" . $row['id_pelapor'] . ";";
    }
}

// menghilangkan karakter ";" dari akhir string
$data = rtrim($data, ";");

// mengembalikan data sebagai hasil
echo $data;

mysqli_close($conn);
?>
