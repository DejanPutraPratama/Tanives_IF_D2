<?php
include "koneksi.php";

// Mendapatkan nilai dari parameter POST
$id_profile = $_POST['id_profile'];

// Menyiapkan query untuk mengambil data dari tabel laporan_keuangan
$query = "SELECT SUM(transaksi_keluar) as total_keluar, SUM(transaksi_masuk) as total_masuk FROM laporan_keuangan WHERE id_profile = '$id_profile'";

// mengeksekusi query dan mendapatkan hasilnya
$result = mysqli_query($conn, $query);

// memproses hasil query menjadi string dengan format yang diinginkan
$data = "";
if ($row = mysqli_fetch_assoc($result)) {
    $total_keluar = ($row['total_keluar'] !== null) ? $row['total_keluar'] : 0;
    $total_masuk = ($row['total_masuk'] !== null) ? $row['total_masuk'] : 0;
    $data = $total_keluar . ";" . $total_masuk;
}

// mengembalikan data sebagai hasil
echo $data;

mysqli_close($conn);
?>
