<?php
include "koneksi.php";

// Menyiapkan query untuk mengambil data dari tabel akun dan profile
$query = "SELECT profile.tipe, akun.username, profile.nama FROM akun INNER JOIN profile ON akun.username = profile.id_akun;";

// mengeksekusi query dan mendapatkan hasilnya
$result = mysqli_query($conn, $query);

// memproses hasil query menjadi string dengan format yang diinginkan
$data = "";
while ($row = mysqli_fetch_assoc($result)) {
    $data .= $row['tipe'] . "||" . $row['username'] . "||" . $row['nama'] . ";";
}

// mengembalikan data sebagai hasil
echo $data;

mysqli_close($conn);
?>
