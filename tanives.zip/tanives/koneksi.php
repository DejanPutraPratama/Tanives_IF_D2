<?php
// Membuat koneksi ke database
$servername = "localhost";
$username = "wirodevm_pplagro";
$password = "7N2lJLWybw";
$dbname = "wirodevm_pplagro";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Memeriksa koneksi
if (!$conn) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
?>