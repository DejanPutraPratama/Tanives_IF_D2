<?php
include "koneksi.php";

// Query untuk mengambil semua data dari tabel "bank"
$query = "SELECT * FROM bank";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0) {
    $data = "";
    while($row = mysqli_fetch_assoc($result)) {
        // Mengambil setiap kolom dan memisahkan dengan tanda "|"
        $data .= $row['kode'] . "|" . $row['nama'].";";
    }
    // Menghapus tanda ";" yang terakhir pada baris terakhir
    $data = rtrim($data, ";");
    echo $data;
} else {
    echo 101;
}

mysqli_close($conn);
?>
