<?php
include "koneksi.php";

$username = $_POST['username'];
$password = mysqli_real_escape_string($conn, $_POST["password"]);

// Enkripsi password menggunakan BCrypt
$hash = password_hash($password, PASSWORD_BCRYPT);

// Update password di tabel akun
$query = "UPDATE akun SET password='$hash' WHERE username='$username'";
$result = mysqli_query($conn, $query);

if ($result) {
  echo 200; // Password berhasil diatur ulang
} else {
  echo 101; // Gagal mengatur ulang password
}

mysqli_close($conn);
?>
