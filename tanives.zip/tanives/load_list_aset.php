<?php
include "koneksi.php";

$query = "SELECT * FROM aset";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0){
  $output = "";
  while($row = mysqli_fetch_assoc($result)){
    $output .= implode("|", $row).";";
  }
  echo $output;
}else{
  echo 101;
}

mysqli_close($conn);
?>
