<?php
include "koneksi.php";

$username = $_POST['username']; // Mengambil username dari form

// Query untuk mengambil profil akun dari tabel "profile" berdasarkan "username"
$query = "SELECT * FROM profile WHERE id_akun = '$username'";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // Mengembalikan item dengan tanda ";"
    $profile = $row['email'] . ";" . $row['nama'] . ";" . $row['tanggal_lahir'] . ";" . $row['nomor_hp'] . ";" . $row['alamat'] . ";" . $row['id_bank'] . ";" . $row['nomor_rekening'] . ";" . $row['nama_pemilik'];
    echo $profile;
} else {
    echo 101;
}

mysqli_close($conn);
?>
